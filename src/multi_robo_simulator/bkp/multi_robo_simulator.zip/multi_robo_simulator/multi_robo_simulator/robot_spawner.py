import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose
from std_msgs.msg import String
from swarm_interfaces.msg import PathArray

import tkinter as tk
from functools import partial


class RobotSpawnerGUI(Node):
    def __init__(self):
        super().__init__('robot_spawner_gui')

        self.bot_ids = {
            "bot1": (1.0, 1.0, 0.0),
            "bot2": (2.0, 2.0, 0.0),
            "bot3": (3.0, 3.0, 0.0),
        }

        self.status_subs = {}
        self.path_subs = {}
        self.pose_pubs = {}
        self.status_pubs = {}

        self.status_labels = {}
        self.path_labels = {}

        # GUI Setup
        self.root = tk.Tk()
        self.root.title("Robot Spawner GUI")

        self.setup_gui()

        # Periodically update GUI
        self.timer = self.create_timer(0.5, self.tk_loop)

    def setup_gui(self):
        # Column titles
        tk.Label(self.root, text="Robots", font=('Arial', 14, 'bold')).grid(row=0, column=0)
        tk.Label(self.root, text="Status", font=('Arial', 14, 'bold')).grid(row=0, column=1)
        tk.Label(self.root, text="First 5 Commands", font=('Arial', 14, 'bold')).grid(row=0, column=2)

        for idx, (bot_id, pose) in enumerate(self.bot_ids.items(), start=1):
            btn = tk.Button(self.root, text=bot_id, width=10,
                            command=partial(self.launch_robot, bot_id, pose))
            btn.grid(row=idx, column=0)

            # Status label
            status_lbl = tk.Label(self.root, text="---", width=15)
            status_lbl.grid(row=idx, column=1)
            self.status_labels[bot_id] = status_lbl

            # Path label
            path_lbl = tk.Label(self.root, text="---", width=30)
            path_lbl.grid(row=idx, column=2)
            self.path_labels[bot_id] = path_lbl

            # ROS communication setup
            self.pose_pubs[bot_id] = self.create_publisher(Pose, f'/{bot_id}/spawn_pose', 10)
            self.status_pubs[bot_id] = self.create_publisher(String, f'/{bot_id}/spawn_status', 10)

            self.status_subs[bot_id] = self.create_subscription(
                String, f'/{bot_id}/status',
                partial(self.status_callback, bot_id), 10)

            self.path_subs[bot_id] = self.create_subscription(
                PathArray, f'/{bot_id}/path',
                partial(self.path_callback, bot_id), 10)

    def launch_robot(self, bot_id, pose_tuple):
        x, y, w = pose_tuple
        pose_msg = Pose()
        pose_msg.position.x = x
        pose_msg.position.y = y
        pose_msg.orientation.z = w  # Assuming z is yaw (for simplicity)

        self.pose_pubs[bot_id].publish(pose_msg)

        status_msg = String()
        status_msg.data = "launched"
        self.status_pubs[bot_id].publish(status_msg)

        self.get_logger().info(f"Launched {bot_id} at ({x}, {y}, {w})")

    def status_callback(self, bot_id, msg):
        self.status_labels[bot_id]['text'] = msg.data

    def path_callback(self, bot_id, msg):
        path_text = ', '.join(map(str, msg.path[:5]))  # First 5 commands
        self.path_labels[bot_id]['text'] = path_text

    def tk_loop(self):
        self.root.update_idletasks()
        self.root.update()


def main(args=None):
    rclpy.init(args=args)
    gui_node = RobotSpawnerGUI()
    try:
        rclpy.spin(gui_node)
    except KeyboardInterrupt:
        pass
    gui_node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
